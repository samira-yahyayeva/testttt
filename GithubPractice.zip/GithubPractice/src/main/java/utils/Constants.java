package utils;

public class Constants {
    public static final String BASE_URL = "https://www.youtube.com";
}